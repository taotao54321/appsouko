#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STRICT
#include <windows.h>

static const char NGHASH_CHAR[] = {
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
    'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
    'U', 'V'
};

#define NGHASH_STR_LEN 26
#define NGHASH_MD5_PAD 1

#define MD5_LEN 16
#define MD5_STR_LEN 32

#define CLIP_OPEN_RETRY_COUNT 3
#define CLIP_OPEN_RETRY_WAIT 100 /* ms */

static void warn(const char* msg)
{
    fputs(msg, stderr);
    putc('\n', stderr);
}

static void error(const char* msg)
{
    warn(msg);
    exit(1);
}

static unsigned int make_word(unsigned char lo, unsigned char hi)
{
    return lo + (hi << 8);
}

static void nghash_encode(char* nghash_str, const unsigned char* md5)
{
    unsigned char s[MD5_LEN + NGHASH_MD5_PAD];
    int i;

    memcpy(s, md5, MD5_LEN);
    memset(s+MD5_LEN, 0, NGHASH_MD5_PAD);

    for(i = 0; i < NGHASH_STR_LEN; ++i)
        nghash_str[i] = NGHASH_CHAR[((make_word(s[5*i/8], s[5*i/8+1])) >> (5*i%8)) & 0x1F];

    nghash_str[NGHASH_STR_LEN] = '\0';
}

static void read_md5(unsigned char* md5, const char* md5_str)
{
    char byte_str[3];
    int i;

    byte_str[2] = '\0';
    for(i = 0; i < MD5_LEN; ++i){
        memcpy(byte_str, md5_str + 2*i, 2);
        md5[i] = strtol(byte_str, NULL, 16);
    }
}

static int clip_put(const char* str)
{
    HGLOBAL h_clip_data = NULL;
    char* clip_str;
    int clip_open_ok = 0;
    HANDLE clip_set_ok = NULL;
    int i;
    int ret = 0;

    if(!(h_clip_data = GlobalAlloc(GMEM_MOVEABLE, strlen(str)+1))) goto FINISH;
    if(!(clip_str = GlobalLock(h_clip_data))) goto FINISH;
    strcpy(clip_str, str);
    GlobalUnlock(h_clip_data);

    for(i = 0; i < CLIP_OPEN_RETRY_COUNT; ++i){
        if((clip_open_ok = OpenClipboard(NULL)))
            break;
        Sleep(CLIP_OPEN_RETRY_WAIT);
    }
    if(!clip_open_ok) goto FINISH;
    if(!EmptyClipboard()) goto FINISH;
    if(!(clip_set_ok = SetClipboardData(CF_TEXT, h_clip_data))) goto FINISH;

    ret = 1;
FINISH:
    if(clip_open_ok) CloseClipboard();
    if(!clip_set_ok && h_clip_data) GlobalFree(h_clip_data);

    return ret;
}

static void usage()
{
    error("Usage: nghash-clip <MD5>");
}

int main(int argc, char** argv)
{
    unsigned char md5[MD5_LEN];
    char nghash_str[NGHASH_STR_LEN+1];

    if(argc != 2 || strlen(argv[1]) != MD5_STR_LEN) usage();

    read_md5(md5, argv[1]);

    nghash_encode(nghash_str, md5);

    if(!clip_put(nghash_str))
        warn("Warning: Can't put data to clipboard");

    puts(nghash_str);

    return 0;
}
