#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char NGHASH_CHAR[] = {
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
    'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
    'U', 'V'
};

#define NGHASH_STR_LEN 26
#define NGHASH_MD5_PAD 1

#define MD5_LEN 16
#define MD5_STR_LEN 32

static void error(const char* msg)
{
    fputs(msg, stderr);
    putc('\n', stderr);
    exit(1);
}

static unsigned int make_word(unsigned char lo, unsigned char hi)
{
    return lo + (hi << 8);
}

static void nghash_encode(char* nghash_str, const unsigned char* md5)
{
    unsigned char s[MD5_LEN + NGHASH_MD5_PAD];
    int i;

    memcpy(s, md5, MD5_LEN);
    memset(s+MD5_LEN, 0, NGHASH_MD5_PAD);

    for(i = 0; i < NGHASH_STR_LEN; ++i)
        nghash_str[i] = NGHASH_CHAR[((make_word(s[5*i/8], s[5*i/8+1])) >> (5*i%8)) & 0x1F];

    nghash_str[NGHASH_STR_LEN] = '\0';
}

static void read_md5(unsigned char* md5, const char* md5_str)
{
    char byte_str[3];
    int i;

    byte_str[2] = '\0';
    for(i = 0; i < MD5_LEN; ++i){
        memcpy(byte_str, md5_str + 2*i, 2);
        md5[i] = strtol(byte_str, NULL, 16);
    }
}

static void usage()
{
    error("Usage: nghash <MD5>");
}

int main(int argc, char** argv)
{
    unsigned char md5[MD5_LEN];
    char nghash_str[NGHASH_STR_LEN+1];

    if(argc != 2 || strlen(argv[1]) != MD5_STR_LEN) usage();

    read_md5(md5, argv[1]);

    nghash_encode(nghash_str, md5);

    puts(nghash_str);

    return 0;
}
