module("binary", package.seeall)

function num_stou(n, size)
    if n < 0 then
        n = n + 2^(8*size)
    end
    return n
end

function num_utos(n, size)
    if n >= 2^(8*size-1) then
        n = n - 2^(8*size)
    end
    return n
end

function numdec_s_le(buf, size)
    local n = numdec_u_le(buf, size)
    return num_utos(n, size)
end

function numdec_u_le(buf, size)
    local n = 0
    for i = 1, size do
        n = n + 2^(8*(i-1)) * buf[i]
    end
    return n
end

function numdec_s_be(buf, size)
    local n = numdec_u_be(buf, size)
    return num_utos(n, size)
end

function numdec_u_be(buf, size)
    local n = 0
    for i = 1, size do
        n = n + 2^(8*(size-i)) * buf[i]
    end
    return n
end

function numdec_s32_le(buf)
    return numdec_s_le(buf, 4)
end

function numdec_u32_le(buf)
    return numdec_u_le(buf, 4)
end

function numdec_s24_le(buf)
    return numdec_s_le(buf, 3)
end

function numdec_u24_le(buf)
    return numdec_u_le(buf, 3)
end

function numdec_s16_le(buf)
    return numdec_s_le(buf, 2)
end

function numdec_u16_le(buf)
    return numdec_u_le(buf, 2)
end

function numdec_s32_be(buf)
    return numdec_s_be(buf, 4)
end

function numdec_u32_be(buf)
    return numdec_u_be(buf, 4)
end

function numdec_s24_be(buf)
    return numdec_s_be(buf, 3)
end

function numdec_u24_be(buf)
    return numdec_u_be(buf, 3)
end

function numdec_s16_be(buf)
    return numdec_s_be(buf, 2)
end

function numdec_u16_be(buf)
    return numdec_u_be(buf, 2)
end

function numenc_s_le(n, size)
    return numenc_u_le(num_stou(n, size), size)
end

function numenc_u_le(n, size)
    local buf = {}
    for i = 1, size do
        buf[i] = n % 0x100
        n = math.floor(n / 0x100)
    end
    return buf
end

function numenc_s_be(n, size)
    return numenc_u_be(num_stou(n, size), size)
end

function numenc_u_be(n, size)
    local buf = {}
    for i = 1, size do
        buf[size-i+1] = n % 0x100
        n = math.floor(n / 0x100)
    end
    return buf
end

function numenc_s32_le(n)
    return numenc_s_le(n, 4)
end

function numenc_u32_le(n)
    return numenc_u_le(n, 4)
end

function numenc_s24_le(n)
    return numenc_s_le(n, 3)
end

function numenc_u24_le(n)
    return numenc_u_le(n, 3)
end

function numenc_s16_le(n)
    return numenc_s_le(n, 2)
end

function numenc_u16_le(n)
    return numenc_u_le(n, 2)
end

function numenc_s32_be(n)
    return numenc_s_be(n, 4)
end

function numenc_u32_be(n)
    return numenc_u_be(n, 4)
end

function numenc_s24_be(n)
    return numenc_s_be(n, 3)
end

function numenc_u24_be(n)
    return numenc_u_be(n, 3)
end

function numenc_s16_be(n)
    return numenc_s_be(n, 2)
end

function numenc_u16_be(n)
    return numenc_u_be(n, 2)
end

function mem_read_bytes(addr, len)
    local buf = {}
    for i = 1, len do
        buf[i] = memory.readbyte(addr+(i-1))
    end
    return buf
end

function mem_read_s_le(addr, size)
    local buf = mem_read_bytes(addr, size)
    return numdec_s_le(buf, size)
end

function mem_read_u_le(addr, size)
    local buf = mem_read_bytes(addr, size)
    return numdec_u_le(buf, size)
end

function mem_read_s_be(addr, size)
    local buf = mem_read_bytes(addr, size)
    return numdec_s_be(buf, size)
end

function mem_read_u_be(addr, size)
    local buf = mem_read_bytes(addr, size)
    return numdec_u_be(buf, size)
end

function mem_read_s32_le(addr)
    return mem_read_s_le(addr, 4)
end

function mem_read_u32_le(addr)
    return mem_read_u_le(addr, 4)
end

function mem_read_s24_le(addr)
    return mem_read_s_le(addr, 3)
end

function mem_read_u24_le(addr)
    return mem_read_u_le(addr, 3)
end

function mem_read_s16_le(addr)
    return mem_read_s_le(addr, 2)
end

function mem_read_u16_le(addr)
    return mem_read_u_le(addr, 2)
end

function mem_read_s32_be(addr)
    return mem_read_s_be(addr, 4)
end

function mem_read_u32_be(addr)
    return mem_read_u_be(addr, 4)
end

function mem_read_s24_be(addr)
    return mem_read_s_be(addr, 3)
end

function mem_read_u24_be(addr)
    return mem_read_u_be(addr, 3)
end

function mem_read_s16_be(addr)
    return mem_read_s_be(addr, 2)
end

function mem_read_u16_be(addr)
    return mem_read_u_be(addr, 2)
end

function mem_read_s8(addr)
    return num_utos(mem_read_u8(addr), 1)
end

function mem_read_u8(addr)
    return memory.readbyte(addr)
end

function mem_write_bytes(addr, buf)
    for i = 1, #buf do
        memory.writebyte(addr, buf[i])
    end
end

function mem_write_s_le(addr, n, size)
    local buf = numenc_s_le(n, size)
    mem_write_bytes(addr, buf)
end

function mem_write_u_le(addr, n, size)
    local buf = numenc_u_le(n, size)
    mem_write_bytes(addr, buf)
end

function mem_write_s_be(addr, n, size)
    local buf = numenc_s_be(n, size)
    mem_write_bytes(addr, buf)
end

function mem_write_u_be(addr, n, size)
    local buf = numenc_u_be(n, size)
    mem_write_bytes(addr, buf)
end

function mem_write_s32_le(addr, n)
    mem_write_s_le(addr, n, 4)
end

function mem_write_u32_le(addr, n)
    mem_write_u_le(addr, n, 4)
end

function mem_write_s24_le(addr, n)
    mem_write_s_le(addr, n, 3)
end

function mem_write_u24_le(addr, n)
    mem_write_u_le(addr, n, 3)
end

function mem_write_s16_le(addr, n)
    mem_write_s_le(addr, n, 2)
end

function mem_write_u16_le(addr, n)
    mem_write_u_le(addr, n, 2)
end

function mem_write_s32_be(addr, n)
    mem_write_s_be(addr, n, 4)
end

function mem_write_u32_be(addr, n)
    mem_write_u_be(addr, n, 4)
end

function mem_write_s24_be(addr, n)
    mem_write_s_be(addr, n, 3)
end

function mem_write_u24_be(addr, n)
    mem_write_u_be(addr, n, 3)
end

function mem_write_s16_be(addr, n)
    mem_write_s_be(addr, n, 2)
end

function mem_write_u16_be(addr, n)
    mem_write_u_be(addr, n, 2)
end

function mem_write_s8(addr, n)
    memory.writebyte(addr, num_stou(n, 1))
end

function mem_write_u8(addr, n)
    memory.writebyte(addr, n)
end
