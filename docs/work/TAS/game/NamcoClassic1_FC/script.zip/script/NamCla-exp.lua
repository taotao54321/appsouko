emu = emu or FCEU

require("binary")

local WIND_SPEED = 0x03
local WIND_DIR = 0x06
--local CLUB_MIN = 0x00
local CLUB_MIN = 0x0B
local CLUB_MAX = 0x11
--local POWER_MIN = 0x18
local POWER_MIN = 0x50
local POWER_MAX = 0x5F
local CURSOR_MIN = 0x00
local CURSOR_MAX = 0x35

function input(inp, n)
    n = n or 1
    for i = 1, n do
        joypad.set(1, inp)
        FCEU.frameadvance()
    end
end

function play_shoot()
    input({ A = 1 })
    input({})
    input({ A = 1 })
    input({})
    input({ A = 1 })
end

function set_param(info)
    binary.mem_write_u8(0x7A, info.wind_speed)
    binary.mem_write_u8(0x7B, info.wind_dir)
    binary.mem_write_u8(0x0307, info.club)
    binary.mem_write_u8(0x64, info.power)
    binary.mem_write_u8(0x63, info.cursor)
end

function wait_shot(info)
    input({})
    while binary.mem_read_u8(0x62) == 5 or binary.mem_read_u8(0x62) == 4 do
        input({})
    end

    info.spin = binary.mem_read_u8(0x65)
    info.x = binary.mem_read_u24_le(0x9C)
    info.y = binary.mem_read_u16_le(0x9F)
end

function log_result(out, info)
    out:write(string.format("%u\t%u\t%u\t%u\t%u\t%u\t%u\t%u\n",
        info.wind_dir, info.wind_speed,
        info.club, info.power, info.cursor, info.spin,
        info.x, info.y
    ))
end

function main()
    local out = io.open("NamCla-exp.log", "w")
    if not out then error("Can't open log file"); end

    emu.speedmode("maximum")
    --emu.speedmode("normal")

    play_shoot()

    local state = savestate.create()
    savestate.save(state)
    savestate.persist(state)
    for club = CLUB_MIN, CLUB_MAX do
        for power = POWER_MIN, POWER_MAX do
            for cursor = CURSOR_MIN, CURSOR_MAX do
                local info = {
                    wind_speed = WIND_SPEED,
                    wind_dir = WIND_DIR,
                    club = club,
                    power = power,
                    cursor = cursor,
                }
                set_param(info)
                wait_shot(info)
                log_result(out, info)

                savestate.load(state)
            end
        end
    end

    out:close()
end

main()
