require "TAS_FCEU"
local TAS = TAS_FCEU

local SPEEDMODE = "maximum"
--SPEEDMODE = "normal"

local FRAME_MAX = 30
--FRAME_MAX = 10
--FRAME_MAX = 5

--local WAIT_ROOM = 120
local WAIT_ROOM = 10

function my_main()
    TAS.rand_init()

    FCEU.speedmode(SPEEDMODE)
    state = savestate.create()
    savestate.save(state)

    for i = 0, FRAME_MAX do
        if attempt_item1_3(state, i) then break; end
    end
end

function attempt_item1_3(state, left_frame)
    local success = false
    for i = 0, FRAME_MAX-4 do
        for j = i+2, FRAME_MAX-2 do
            for k = j+2, FRAME_MAX do
                attempt(FRAME_MAX, { i, j, k }, left_frame)

                TAS.input_right(WAIT_ROOM)

                --[[
                while memory.readbyte(0x20) == 18 or memory.readbyte(0x20) == 19 do
                    TAS.input_none()
                end
                ]]

                --if memory.readbyte(0x20) == 20 then
                if memory.readbyte(0x2C) ~= 1 then
                    local state_good = savestate.create(1)
                    savestate.save(state_good)
                    success = true
                    break
                end

                savestate.load(state)
            end
            if success then break; end
        end
        if success then break; end
    end

    return success
end

function attempt(n_frame, frame_fire, left_frame)
    for i = 0, n_frame do
        inp = {}
        for j = 1, 3 do
            if frame_fire[j] == i then
                inp["B"] = 1
            end
        end
        if left_frame == i then
            inp["left"] = 1
        else
            inp["right"] = 1
        end

        TAS.input(inp)
    end

    --[[
    wait = {}
    wait[1] = frame_fire[1]
    wait[2] = frame_fire[2] - frame_fire[1] - 1
    wait[3] = frame_fire[3] - frame_fire[2] - 1
    wait_last = n_frame - frame_fire[3]

    for i = 1, 3 do
        TAS.input_right(wait[i])
        TAS.input({ right = 1, B = 1 })
    end

    TAS.input_right(wait_last)
    ]]
end

my_main()
