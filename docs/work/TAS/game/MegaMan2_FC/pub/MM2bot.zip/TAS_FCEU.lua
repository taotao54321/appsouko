-- TAS library for FCEU

module("TAS_FCEU", package.seeall)

function input(inp, frames)
    frames = frames or 1
    for i = 1, frames do
        joypad.set(1, inp)
        FCEU.frameadvance()
    end
end

function input_up(frames)
    frames = frames or 1
    input({ up = 1 }, frames)
end

function input_down(frames)
    frames = frames or 1
    input({ down = 1 }, frames)
end

function input_left(frames)
    frames = frames or 1
    input({ left = 1 }, frames)
end

function input_right(frames)
    frames = frames or 1
    input({ right = 1 }, frames)
end

function input_A(frames)
    frames = frames or 1
    input({ A = 1 }, frames)
end

function input_B(frames)
    frames = frames or 1
    input({ B = 1 }, frames)
end

function input_start(frames)
    frames = frames or 1
    input({ start = 1 }, frames)
end

function input_select(frames)
    frames = frames or 1
    input({ select = 1 }, frames)
end

function input_none(frames)
    frames = frames or 1
    for i = 1, frames do
        FCEU.frameadvance()
    end
end

function mem_read_str(addr, len)
    local str = ""

    for i = 0, len-1 do
        local c = string.char(memory.readbyte(addr+i))
        str = str .. c
    end

    return str
end

function rand_init()
    math.randomseed(os.time())
end

function rand(n)
    return math.random(n)
end
