ダブルムーン伝説 (FC) スクリプト集
==================================

DoubleMoon-pos.lua	座標表示
DoubleMoon-rand.lua	乱数表示

DoubleMoon-critbot.lua	会心/痛恨bot(攻撃メッセージが出たら起動)
DoubleMoon-dropbot.lua	アイテムドロップbot(経験値/金取得メッセージが出たら起動)
DoubleMoon-evadebot.lua	回避bot(攻撃メッセージが出たら起動)
DoubleMoon-spbot.lua	特技発動bot(特技に対応する行動のメッセージが出たら起動)

aul.lua	Lua補助ライブラリ
ume.lua	EmuLua補助ライブラリ
