if not bit then require("bit") end

require("aul")
require("ume")

function get_info()
    local info = {}
    info.reg = ume.mem_read_u16_le(0x83)
    info.frame = ume.mem_read_u8(0x01)
    return info
end

function rand_next(reg, frame)
    local carry = 0
    local reg_hi = bit.rshift(reg, 8)
    if reg_hi ~= 0x01 and reg_hi ~= 0x80 then carry = 1 end
    local nx = bit.band(bit.lshift(reg, 1), 0xFFFF)
    nx = bit.bor(nx, carry)
    nx = bit.bor(bit.band(nx, 0xFF00), bit.band(bit.bxor(nx, frame), 0x00FF))
    return nx
end

function on_draw()
    local info = get_info()
    gui.text(0, 8, string.format("F:0x%02X, Rnd:0x%04X, Next:0x%04X",
        info.frame, info.reg, rand_next(info.reg, info.frame)
    ))
end

function main()
    gui.register(on_draw)
end

main()
