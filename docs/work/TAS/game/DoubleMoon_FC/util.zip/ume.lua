module(..., package.seeall)

if not bit then require("bit") end
require("aul")

--********************************************************************
-- emulator
--********************************************************************

function advance(n, pads)
    if n == nil then
        emu.frameadvance()
    else
        for _ in aul.range(1, n) do
            if pads then
                for i,pad in aul.list_enum(pads) do
                    joypad.set(i, pad)
                end
            end
            emu.frameadvance()
        end
    end
end

--********************************************************************
-- memory
--********************************************************************

function mem_read_s8(addr)
    local v = mem_read_u8(addr)
    return v >= 0x80 and v-0x100 or v
end

function mem_read_u8(addr)
    return memory.readbyte(addr)
end

function mem_read_s_le(addr, size)
    local v = mem_read_u_le(addr, size)
    return v >= bit.lshift(1, 8*size-1) and v-bit.lshift(1, 8*size) or v
end

function mem_read_u_le(addr, size)
    local v = 0
    for i in aul.range(1, size) do
        v = bit.bor(v, bit.lshift(mem_read_u8(addr+i-1), 8*(i-1)))
    end
    return v
end

function mem_read_s_be(addr, size)
    local v = mem_read_u_be(addr, size)
    return v >= bit.lshift(1, 8*size-1) and v-bit.lshift(1, 8*size) or v
end

function mem_read_u_be(addr, size)
    local v = 0
    for i in aul.range(1, size) do
        v = bit.bor(v, bit.lshift(mem_read_u8(addr+i-1)), 8*(size-i))
    end
    return v
end

function mem_read_s16_le(addr)
    return mem_read_s_le(addr, 2)
end

function mem_read_u16_le(addr)
    return mem_read_u_le(addr, 2)
end

function mem_read_s24_le(addr)
    return mem_read_s_le(addr, 3)
end

function mem_read_u24_le(addr)
    return mem_read_u_le(addr, 3)
end

function mem_read_s32_le(addr)
    return mem_read_s_le(addr, 4)
end

function mem_read_u32_le(addr)
    return mem_read_u_le(addr, 4)
end

function mem_read_s16_be(addr)
    return mem_read_s_be(addr, 2)
end

function mem_read_u16_be(addr)
    return mem_read_u_be(addr, 2)
end

function mem_read_s24_be(addr)
    return mem_read_s_be(addr, 3)
end

function mem_read_u24_be(addr)
    return mem_read_u_be(addr, 3)
end

function mem_read_s32_be(addr)
    return mem_read_s_be(addr, 4)
end

function mem_read_u32_be(addr)
    return mem_read_u_be(addr, 4)
end

function mem_write_s8(addr, v)
    mem_write_u8(addr, v < 0 and v+0x100 or v)
end

function mem_write_u8(addr, v)
    memory.writebyte(addr, v)
end

function mem_write_s_le(addr, v, size)
    mem_write_u_le(addr, v < 0 and v+bit.lshift(1, 8*size) or v, size)
end

function mem_write_u_le(addr, v, size)
    for i in aul.range(1, size) do
        mem_write_u8(addr+i-1, bit.band(bit.rshift(v, 8*(i-1)), 0xFF))
    end
end

function mem_write_s_be(addr, v, size)
    mem_write_u_be(addr, v < 0 and v+bit.lshift(1, 8*size) or v, size)
end

function mem_write_u_be(addr, v, size)
    for i in aul.range(1, size) do
        mem_write_u8(addr+i-1, bit.band(bit.rshift(v, 8*(size-i)), 0xFF))
    end
end

function mem_write_s16_le(addr, v)
    mem_write_s_le(addr, v, 2)
end

function mem_write_u16_le(addr, v)
    mem_write_u_le(addr, v, 2)
end

function mem_write_s24_le(addr, v)
    mem_write_s_le(addr, v, 3)
end

function mem_write_u24_le(addr, v)
    mem_write_u_le(addr, v, 3)
end

function mem_write_s32_le(addr, v)
    mem_write_s_le(addr, v, 4)
end

function mem_write_u32_le(addr, v)
    mem_write_u_le(addr, v, 4)
end

function mem_write_s16_be(addr, v)
    mem_write_s_be(addr, v, 2)
end

function mem_write_u16_be(addr, v)
    mem_write_u_be(addr, v, 2)
end

function mem_write_s24_be(addr, v)
    mem_write_s_be(addr, v, 3)
end

function mem_write_u24_be(addr, v)
    mem_write_u_be(addr, v, 3)
end

function mem_write_s32_be(addr, v)
    mem_write_s_be(addr, v, 4)
end

function mem_write_u32_be(addr, v)
    mem_write_u_be(addr, v, 4)
end
