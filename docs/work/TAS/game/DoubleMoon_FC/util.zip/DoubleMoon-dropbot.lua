if not bit then require("bit") end

require("aul")
require("ume")

local CODE_DROP = 0x8E29

local ITER = 256

function main()
    movie.rerecordcounting(false)

    emu.speedmode("maximum")
    --emu.unpause()

    local drop = false
    local function on_drop()
        drop = true
    end
    memory.registerexec(CODE_DROP, on_drop)

    local state = savestate.create()
    savestate.save(state)
    for _ = 0, ITER-1 do
        ume.advance(1, {{ A = 1 }})
        ume.advance(2)
        if drop then break end
        savestate.load(state)
        ume.advance(1)
        savestate.save(state)
    end

    memory.registerexec(CODE_DROP, nil)

    emu.speedmode("normal")
    emu.pause()
end

main()
