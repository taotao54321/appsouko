if not bit then require("bit") end

require("aul")
require("ume")

local CODE_SP = 0x9535

local ITER = 256

function main()
    movie.rerecordcounting(false)

    emu.speedmode("maximum")
    --emu.unpause()

    local sp = false
    local function on_sp()
        sp = true
    end
    memory.registerexec(CODE_SP, on_sp)

    local state = savestate.create()
    savestate.save(state)
    for _ = 0, ITER-1 do
        ume.advance(1, {{ A = 1 }})
        ume.advance(2)
        if sp then break end
        savestate.load(state)
        ume.advance(1)
        savestate.save(state)
    end

    memory.registerexec(CODE_SP, nil)

    emu.speedmode("normal")
    emu.pause()
end

main()
