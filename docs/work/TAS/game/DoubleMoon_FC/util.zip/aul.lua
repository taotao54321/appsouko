module(..., package.seeall)

--********************************************************************
-- iterator
--********************************************************************

function iter(it, st, ct)
    if st == nil and ct == nil then
        return it
    else
        return function()
            while true do
                local e = {it(st, ct)}
                ct = e[1]
                return unpack(e)
            end
        end
    end
end

function collect(it)
    local t = {}
    for e in it do
        list_append(t, e)
    end
    return t
end

function range(start, stop, step)
    step = step or 1
    assert(step ~= 0, "range(): step == 0")
    if not stop then
        stop = start
        start = 1
    end
    local i_next = start

    if step > 0 then
        return function()
            local i_curr = i_next
            i_next = i_next + step
            if i_curr <= stop then return i_curr end
        end
    else
        return function()
            local i_curr = i_next
            i_next = i_next + step
            if i_curr >= stop then return i_curr end
        end
    end
end

--********************************************************************
-- algorithm
--********************************************************************

function all(it)
    for e in it do
        if not e then return false end
    end
    return true
end

function any(it)
    for e in it do
        if e then return true end
    end
    return false
end

function sum(it, start)
    local v = start
    if v == nil then v = 0 end
    for e in it do
        v = v + e
    end
    return v
end

function count(it)
    local n = 0
    for _ in it do
        n = n + 1
    end
    return n
end

function foreach(f, it)
    for e in it do
        f(e)
    end
end

function map(f, it)
    return function()
        local e = it()
        if e ~= nil then
            return f(e)
        end
    end
end

function filter(f, it)
    return function()
        while true do
            local e = it()
            if e == nil then return nil end
            if f(e) then return e end
        end
    end
end

--********************************************************************
-- functional
--********************************************************************

function cmp(lhs, rhs)
    if lhs > rhs then return 1
    elseif lhs < rhs then return -1
    else return 0 end
end

--********************************************************************
-- number
--********************************************************************

function isnan(x)
    return type(x) == "number" and x ~= x
end

function isinf(x)
    if x == math.huge then return 1
    elseif x == -math.huge then return -1
    else return 0 end
end

function isfinite(x)
    return -math.huge < x and x < math.huge
end

function isinteger(x)
    return isfinite(x) and x % 1 == 0
end

function round(x)
    return x >= 0 and math.floor(x+0.5) or -math.floor(math.abs(x)+0.5)
end

function trunc(x)
    return x >= 0 and math.floor(x) or math.ceil(x)
end

--********************************************************************
-- string
--********************************************************************

function str_iter(s)
    return iter(s:gmatch("(.)"))
end

function str_startswith(s, prefix)
    return s:sub(1, #prefix) == prefix
end

function str_endswith(s, suffix)
    return s:sub(-#suffix) == suffix
end

--********************************************************************
-- list
--********************************************************************

function list_iter(l)
    local i = 0
    return function()
        i = i + 1
        return l[i]
    end
end

function list_enum(l)
    return iter(ipairs(l))
end

function list_append(l, e)
    l[#l+1] = e
end

function list_insert(l, i, e)
    table.insert(l, i, e)
end

function list_pop(l)
    l[#l] = nil
end

function list_remove(l, i)
    table.remove(l, i)
end

function list_sort(l, cmp)
    table.sort(l, cmp)
end

function list_copy(l)
    return {unpack(l)}
end

--********************************************************************
-- table
--********************************************************************

function table_iter(t)
    return iter(pairs(t))
end

function table_keys(t)
    return map(function(k, _)
        return k
    end, table_iter(t))
end

function table_values(t)
    return map(function(_, v)
        return v
    end, table_iter(t))
end

function table_get(t, k, def)
    local v = t[k]
    if v == nil then v = def end
    return v
end

function table_pop(t, k, def)
    local v = table_get(t, k, def)
    t[k] = nil
    return v
end

function table_setdefault(t, k, def)
    if t[k] == nil then t[k] = def end
    return t[k]
end

function table_copy(t)
    local t2 = {}
    for k, v in table_iter(t) do
        t2[k] = v
    end
    return t2
end

function table_size(t)
    return count(table_iter(t))
end
