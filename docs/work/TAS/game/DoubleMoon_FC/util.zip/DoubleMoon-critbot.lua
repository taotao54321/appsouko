if not bit then require("bit") end

require("aul")
require("ume")

local CODE_CRIT = 0x9182

local ITER = 256

function main()
    movie.rerecordcounting(false)

    emu.speedmode("maximum")
    --emu.unpause()

    local crit = false
    local function on_crit()
        crit = true
    end
    memory.registerexec(CODE_CRIT, on_crit)

    local state = savestate.create()
    savestate.save(state)
    for _ = 0, ITER-1 do
        ume.advance(1, {{ A = 1 }})
        ume.advance(2)
        if crit then break end
        savestate.load(state)
        ume.advance(1)
        savestate.save(state)
    end

    memory.registerexec(CODE_CRIT, nil)

    emu.speedmode("normal")
    emu.pause()
end

main()
