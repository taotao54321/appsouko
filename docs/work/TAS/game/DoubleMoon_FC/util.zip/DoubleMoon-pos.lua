if not bit then require("bit") end

function get_info()
    local info = {}
    info.map = memory.readbyte(0x56)
    info.pos_x = memory.readbyte(0x04)
    info.pos_y = memory.readbyte(0x05)
    info.pos_x_bak = memory.readbyte(0x57)
    info.pos_y_bak = memory.readbyte(0x58)
    info.ship_pos_x = memory.readbyte(0x6439)
    info.ship_pos_y = memory.readbyte(0x6438)
    return info
end

function on_draw()
    local info = get_info()
    gui.text(0, 8, string.format("MAP:0x%02X, (%d,%d), bak:(%d,%d), ship:(%d,%d)",
        info.map,
        info.pos_x, info.pos_y,
        info.pos_x_bak, info.pos_y_bak,
        info.ship_pos_x, info.ship_pos_y
    ))
end

function main()
    gui.register(on_draw)
end

main()
