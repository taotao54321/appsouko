local bit = require("bit")
local binary = require("binary")

local emu = FCEU

local POS_CURB_LIMIT_MAX = 0x0061FF
local POS_CURB_LIMIT_MIN = 0xFFA200 - 0x1000000

local ENGINE_BRAKE = {
    --LOW
    {
        {
            0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100,
            0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200,
            0x0300, 0x0300, 0x0300, 0x0300, 0x0400, 0x0400, 0x0400, 0x0400,
            0x0500, 0x0500, 0x0600, 0x0600, 0x0700, 0x0700, 0x0800, 0x0800,
        },
        {
            0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100,
            0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200,
            0x0300, 0x0300, 0x0300, 0x0300, 0x0400, 0x0400, 0x0400, 0x0400,
            0x0500, 0x0500, 0x0600, 0x0600, 0x0700, 0x0700, 0x0800, 0x0800,
        },
    },
    --HI
    {
        {
            0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100,
            0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100,
            0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100,
            0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100, 0x0100,
        },
        {
            0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200,
            0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200,
            0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200,
            0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200,
        },
    },
}

local ACCEL = {
    -- LOW
    {
        {
            0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200, 0x0200,
            0x0300, 0x0300, 0x0300, 0x0280, 0x0240, 0x0220, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0,
        },
        {
            0x0220, 0x0240, 0x0280, 0x0300, 0x0300, 0x0300, 0x0300, 0x0300,
            0x0400, 0x0400, 0x0400, 0x0400, 0x0300, 0x0280, 0x0240, 0,
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0,
        },
    },
    -- HI
    {
        {
            0x0120, 0x0130, 0x0140, 0x0150, 0x0160, 0x0170, 0x0180, 0x0198,
            0x01B0, 0x01C8, 0x01E0, 0x01F8, 0x0210, 0x0230, 0x0250, 0x0270,
            0x0240, 0x0220, 0x02F0, 0x01C0, 0x0190, 0x0168, 0x0140, 0x0120,
            0x0118, 0x0110, 0x0140, 0x0180, 0x0180, 0x0180, 0x0140, 0x00FF,
        },
        {
            0x0240, 0x0260, 0x0280, 0x02A0, 0x02C0, 0x02E0, 0x0300, 0x0320,
            0x0340, 0x0360, 0x0380, 0x03A0, 0x03B0, 0x03C0, 0x03D0, 0x03E0,
            0x03C0, 0x03A0, 0x0380, 0x0360, 0x0340, 0x0320, 0x0300, 0x02E0,
            0x0300, 0x0320, 0x0340, 0x0340, 0x0340, 0x0340, 0x0320, 0x00FF,
        },
    },
}

local CURVE_THRESHOLD = { 8, 24, 40 }
local CURVE_SPEED_LIMIT = {
    -- LV1
    {
        { 369, 339, 309 },
        { 509, 479, 449 },
    },
    -- LV2
    {
        { 349, 319, 289 },
        { 489, 459, 429 },
    },
    -- LV3
    {
        { 329, 299, 269 },
        { 469, 439, 409 },
    },
}

local MOVE_MASK = { 0x80, 0x40, 0x40 }
local MOVE_STR = { "R", "L" }

local RAND_PERIOD = 0xFFFE

local rand_idx = {}

function get_engine_brake(speed, gear, turbo)
    local speed_idx = math.floor((speed/0x0100)/16) + 1
    local gear_idx = gear+1
    local turbo_idx = 1
    if turbo then turbo_idx = turbo_idx+1; end

    return ENGINE_BRAKE[gear_idx][turbo_idx][speed_idx]
end

function get_accel(speed, gear, turbo)
    local speed_idx = math.floor((speed/0x0100)/16) + 1
    local gear_idx = gear+1
    local turbo_idx = 1
    if turbo then turbo_idx = turbo_idx+1; end

    return ACCEL[gear_idx][turbo_idx][speed_idx]
end

function get_speed_limit(level, curve, turbo)
    local curve_abs = math.abs(curve)
    local curve_idx = 0
    for i = 1, #CURVE_THRESHOLD do
        if curve_abs >= CURVE_THRESHOLD[i] then
            curve_idx = curve_idx+1
        end
    end
    if curve_idx == 0 then return nil; end

    local level_idx = level+1

    local turbo_idx = 1
    if turbo then turbo_idx = turbo_idx+1; end

    return CURVE_SPEED_LIMIT[level_idx][turbo_idx][curve_idx]
end

function get_move_dir(move, level)
    local mask = MOVE_MASK[level+1]
    if bit.band(move, mask) == 0 then
        return 1 -- R
    else
        return 2 -- L
    end
end

function chk_enemy_pop(rand1, speed)
    if speed >= 0xC800 then
        return bit.band(rand1, 0x1F) == 0
    else
        return bit.band(rand1, 0x01FF) == 0
    end
end

function rand_shift(r)
    local bit_new = bit.band(bit.bnot(bit.bxor(bit.rshift(r,15), bit.rshift(r,1), r)), 0x0001)
    return bit.band(bit.bor(bit.lshift(r,1), bit_new), 0xFFFF)
end

function init_rand_idx()
    local r = 0x0000
    for i = 1, RAND_PERIOD do
        rand_idx[r] = i
        r = rand_shift(r)
    end
end

function get_info()
    local info = {}

    info.level = binary.mem_read_u8(0x33)
    info.frame = binary.mem_read_u8(0x4F)
    info.gear = binary.mem_read_u8(0x47)
    info.turbo = binary.mem_read_u8(0x75) ~= 0
    local pos_buf = { binary.mem_read_u8(0x4D), binary.mem_read_u8(0x4C), binary.mem_read_u8(0x4E) }
    info.pos = binary.numdec_s24_be(pos_buf)
    info.speed = binary.mem_read_u24_be(0x50)
    info.rpm = binary.mem_read_u8(0x53)
    info.distance = binary.mem_read_u16_le(0x41)
    info.distance_way = binary.mem_read_u8(0x43)

    local way_ptr = binary.mem_read_u16_le(0x3C)
    info.way_curve = binary.mem_read_s8(way_ptr)
    info.way_len = binary.mem_read_u8(way_ptr+1)

    info.enemy = {}
    for i = 1, 3 do
        local e = {}
        e.x = binary.mem_read_u8(0x8C+i-1)
        e.z = 256*binary.mem_read_u8(0x8F+i-1) + binary.mem_read_u8(0x92+i-1)
        e.move = binary.mem_read_u8(0x98+i-1)
        info.enemy[i] = e
    end

    info.rand0 = binary.mem_read_u16_le(0x2E)
    info.rand1 = binary.mem_read_u16_le(0x30)

    return info
end

function draw_info(info)
    local str_pos = string.format("POS: %.3f (0x%06X)", info.pos/256.0, binary.num_stou(info.pos, 3))
    if info.pos < POS_CURB_LIMIT_MIN or info.pos > POS_CURB_LIMIT_MAX then
        str_pos = str_pos .. " curb!"
    end

    local engine_brake = get_engine_brake(info.speed, info.gear, info.turbo)
    local accel = get_accel(info.speed, info.gear, info.turbo)
    local str_speed = string.format("SPD: %.3f (0x%06X) %.3f-%.3f=%.3f",
                                    info.speed/256.0, info.speed,
                                    accel/256.0, engine_brake/256.0, (accel-engine_brake)/256.0)

    local speed_limit = get_speed_limit(info.level, info.way_curve, info.turbo)
    local str_way = string.format("WAY: %d, %u/%u", info.way_curve, info.distance_way, info.way_len)
    if speed_limit then
        str_way = str_way .. string.format(", lim:%03u", speed_limit)
    end

    local str_enemy = "ENM: "
    for i = 1, 3 do
        local e = info.enemy[i]
        local x_str, z_str = "----", "------"
        if e.z < 0xF000 then
            x_str = string.format("0x%02X", e.x)
            z_str = string.format("0x%04X", e.z)
        end
        str_enemy = str_enemy .. string.format("(%s,%s)", x_str, z_str)
        if i ~= 3 then str_enemy = str_enemy .. " "; end
    end

    local str_enemy_act = "ACT: "
    for i = 1, 3 do
        local e = info.enemy[i]
        local move_str = string.format("0x%02X(%s)", e.move, MOVE_STR[get_move_dir(e.move, info.level)])
        str_enemy_act = str_enemy_act .. move_str
        if i ~= 3 then str_enemy_act = str_enemy_act .. " "; end
    end
    local rand1_str = string.format("rand1:%d", rand_idx[info.rand1])
    if chk_enemy_pop(info.rand1, info.speed) then
        rand1_str = rand1_str .. "(!)"
    end
    str_enemy_act = str_enemy_act .. "  " .. rand1_str

    --gui.text(0, 48, string.format("POS: %.3f (0x%06X)", info.pos/256.0, binary.num_stou(info.pos, 3)))
    gui.text(0, 40, str_pos)
    --gui.text(0, 48, string.format("SPD: %.3f (0x%06X)", info.speed/256.0, info.speed))
    gui.text(0, 48, str_speed)
    gui.text(0, 56, string.format("RPM: %u", info.rpm))
    gui.text(0, 72, string.format("DIS: %.3f (0x%04X)", info.distance/256.0, info.distance))
    --gui.text(0, 80, string.format("DIS: %u", info.distance))
    gui.text(0, 80, str_way)

    gui.text(0, 96, str_enemy)
    gui.text(0, 104, str_enemy_act)

    gui.text(238, 216, string.format("%03u", info.frame))
end

function draw()
    local info = get_info()

    -- �n�[�h���Z�b�g����̓�����������������ĂȂ��̂ŏ��\�����Ȃ�
    if binary.mem_read_u8(0x0600) == 0xA5 then
        draw_info(info)
    end
end

function main()
    init_rand_idx()

    gui.register(draw)
    while true do
        emu.frameadvance()
    end

    --[[
    while(true) do
        draw()
        emu.frameadvance()
    end
    ]]
end

main()
