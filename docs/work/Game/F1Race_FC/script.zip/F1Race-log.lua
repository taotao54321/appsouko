require("binary")

local emu = FCEU

function err(msg)
    error(msg)
end

function get_info()
    local info = {}

    info.frame = binary.mem_read_u8(0x4F)
    local pos_buf = { binary.mem_read_u8(0x4D), binary.mem_read_u8(0x4C), binary.mem_read_u8(0x4E) }
    info.pos = binary.numdec_s24_be(pos_buf)
    info.speed = binary.mem_read_u24_be(0x50)
    info.distance = binary.mem_read_u16_le(0x41)
    info.distance_way = binary.mem_read_u8(0x43)

    local way_ptr = binary.mem_read_u16_le(0x3C)
    info.way_curve = binary.mem_read_s8(way_ptr)
    info.way_len = binary.mem_read_u8(way_ptr+1)

    return info
end

function fmt_float(x)
    return string.format("%.3f", x)
end

function do_log(out)
    local info = get_info()

    local line = table.concat({
        movie.framecount(),
        info.frame,
        fmt_float(info.pos/256.0),
        fmt_float(info.speed/256.0),
        fmt_float(info.distance/256.0),
        info.way_curve,
        string.format("%u/%u", info.distance_way, info.way_len),
    }, "\t")
    out:write(line, "\n")
end

function main()
    if not movie.active() then return; end
    if movie.mode() ~= "playback" then return; end

    local filename = movie.getname() .. ".log"
    local out = io.open(filename, "w")
    if not out then err("Can't open file"); end

    while movie.mode() == "playback" do
        do_log(out)
        emu.frameadvance()
    end

    out:close()
end

main()
